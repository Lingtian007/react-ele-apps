
// 保存用户数据
export const SAVE_USERINFO = 'SAVE_USERINFO'

// 保存用户信息
export const SAVE_ATTRINFO = 'SAVE_ATTRINFO'

// 修改用信息
export const MODIFY_USERINFO = 'MODIFY_USERINFO'
